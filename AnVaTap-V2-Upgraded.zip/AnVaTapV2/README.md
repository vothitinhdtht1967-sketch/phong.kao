# Ăn và Tập V2

Bản nâng cấp gồm:
- TDEE tự tính từ tuổi, chiều cao, cân nặng và mức vận động.
- Có thể chỉnh trực tiếp mục tiêu kcal/ngày.
- Có thể chỉnh mục tiêu protein.
- Theo dõi thời gian tập gym và chạy bằng đồng hồ Start/Stop.
- Lưu thời gian tập trong ngày.
- Marathon 4 tuần có mục tiêu pace và đánh dấu hoàn thành.
