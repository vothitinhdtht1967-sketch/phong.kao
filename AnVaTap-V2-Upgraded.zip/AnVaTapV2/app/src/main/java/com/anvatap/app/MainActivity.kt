package com.anvatap.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

data class Food(val name:String,val kcal:Double,val protein:Double,val carb:Double,val fat:Double)
data class RunPlan(val day:String,val type:String,val distance:String,val pace:String)

val FOOD_DB=listOf(
    Food("Cơm trắng",130.0,2.7,28.0,0.3),
    Food("Ức gà",165.0,31.0,0.0,3.6),
    Food("Thịt bò",250.0,26.0,0.0,15.0),
    Food("Cá",150.0,22.0,0.0,6.0),
    Food("Trứng gà",143.0,12.6,0.7,9.5),
    Food("Sữa tươi",60.0,3.2,4.8,3.2),
    Food("Whey",400.0,75.0,10.0,6.0),
    Food("Rau xanh",25.0,2.0,4.0,0.3),
    Food("Chuối",89.0,1.1,23.0,0.3)
)

val RUN_PLAN=listOf(
    RunPlan("Tuần 1 • T2","Easy","6 km","6:00–6:30/km"),
    RunPlan("Tuần 1 • T4","Tempo","6 km","5:10–5:30/km"),
    RunPlan("Tuần 1 • T7","Long run","12 km","6:00–6:30/km"),
    RunPlan("Tuần 2 • T2","Easy","7 km","6:00–6:30/km"),
    RunPlan("Tuần 2 • T4","Interval","6×800 m","4:40–5:00/km"),
    RunPlan("Tuần 2 • T7","Long run","15 km","5:50–6:20/km"),
    RunPlan("Tuần 3 • T2","Easy","7 km","5:50–6:20/km"),
    RunPlan("Tuần 3 • T5","Tempo","8 km","5:00–5:20/km"),
    RunPlan("Tuần 3 • CN","Long run","18 km","5:50–6:20/km"),
    RunPlan("Tuần 4 • T2","Recovery","5 km","6:15–6:45/km"),
    RunPlan("Tuần 4 • T4","Interval","5×1 km","4:35–4:55/km"),
    RunPlan("Tuần 4 • T7","Long run","12 km","6:00–6:30/km")
)

class MainActivity:ComponentActivity(){
    private val ask=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            ask.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent{AnVaTap(this)}
    }
}


@Composable
fun AnVaTap(c:Context){
    val p=c.getSharedPreferences("anvatap",0)
    var page by remember{mutableIntStateOf(0)}
    var kcal by remember{mutableDoubleStateOf(p.getFloat("kcal",0f).toDouble())}
    var protein by remember{mutableDoubleStateOf(p.getFloat("protein",0f).toDouble())}
    var gym by remember{mutableStateOf(p.getBoolean("gym",false))}
    var run by remember{mutableStateOf(p.getBoolean("run",false))}
    var gymSeconds by remember{mutableLongStateOf(p.getLong("gymSeconds",0L))}
    var runSeconds by remember{mutableLongStateOf(p.getLong("runSeconds",0L))}
    var age by remember{mutableIntStateOf(p.getInt("age",36))}
    var height by remember{mutableDoubleStateOf(p.getFloat("height",182f).toDouble())}
    var weight by remember{mutableDoubleStateOf(p.getFloat("weight",73f).toDouble())}
    var activity by remember{mutableDoubleStateOf(p.getFloat("activity",1.55f).toDouble())}
    var calorieGoal by remember{mutableIntStateOf(p.getInt("calorieGoal",0))}
    var proteinGoal by remember{mutableIntStateOf(p.getInt("proteinGoal",0))}
    var showSettings by remember{mutableStateOf(false)}

    val bmr=10*weight+6.25*height-5*age+5
    val tdee=(bmr*activity).roundToInt()
    val autoGoal=(tdee+300).coerceAtLeast(1200)
    val goal=if(calorieGoal>0) calorieGoal else autoGoal
    val pg=if(proteinGoal>0) proteinGoal else (weight*2).roundToInt()
    val fg=(weight*.9).roundToInt()
    val cg=((goal-pg*4-fg*9)/4).coerceAtLeast(0.0).roundToInt()

    fun save(){
        p.edit().putFloat("kcal",kcal.toFloat()).putFloat("protein",protein.toFloat())
            .putBoolean("gym",gym).putBoolean("run",run)
            .putLong("gymSeconds",gymSeconds).putLong("runSeconds",runSeconds)
            .putInt("age",age).putFloat("height",height.toFloat()).putFloat("weight",weight.toFloat())
            .putFloat("activity",activity.toFloat()).putInt("calorieGoal",calorieGoal)
            .putInt("proteinGoal",proteinGoal).apply()
    }

    MaterialTheme(colorScheme=darkColorScheme()){
        Scaffold(
            topBar={TopAppBar(title={Text("Ăn và Tập V2",fontWeight=FontWeight.Bold)})},
            bottomBar={
                NavigationBar{
                    listOf("Ăn","Tập","Marathon").forEachIndexed{i,s->
                        NavigationBarItem(page==i,{page=i},
                            {Icon(if(i==0)Icons.Default.Restaurant else if(i==1)Icons.Default.FitnessCenter else Icons.Default.DirectionsRun,s)},
                            label={Text(s)})
                    }
                }
            }
        ){pad->
            when(page){
                0->Eat(Modifier.padding(pad),kcal,protein,goal,pg,cg,fg,
                    add={f,g->{kcal+=f.kcal*g/100;protein+=f.protein*g/100;save()}},
                    reset={kcal=0.0;protein=0.0;save()})
                1->Train(Modifier.padding(pad),gym,run,gymSeconds,runSeconds,
                    onGym={gym=!gym;save()},onRun={run=!run;save()},
                    onGymSeconds={gymSeconds=it;save()},onRunSeconds={runSeconds=it;save()},
                    onSettings={showSettings=true})
                2->Marathon(Modifier.padding(pad))
            }
        }
    }

    if(showSettings){
        SettingsDialog(
            age=age,height=height,weight=weight,activity=activity,
            calorieGoal=calorieGoal,proteinGoal=proteinGoal,
            onSave={a,h,w,act,cg2,pg2->
                age=a;height=h;weight=w;activity=act;calorieGoal=cg2;proteinGoal=pg2;save();showSettings=false
            },
            onDismiss={showSettings=false}
        )
    }
}

@Composable
fun SettingsDialog(
    age:Int,height:Double,weight:Double,activity:Double,calorieGoal:Int,proteinGoal:Int,
    onSave:(Int,Double,Double,Double,Int,Int)->Unit,onDismiss:()->Unit
){
    var a by remember{mutableStateOf(age.toString())}
    var h by remember{mutableStateOf(height.toString())}
    var w by remember{mutableStateOf(weight.toString())}
    var act by remember{mutableStateOf(activity.toString())}
    var kcal by remember{mutableStateOf(if(calorieGoal>0) calorieGoal.toString() else "")}
    var protein by remember{mutableStateOf(if(proteinGoal>0) proteinGoal.toString() else "")}
    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text("Cài đặt mục tiêu")},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(7.dp)){
                OutlinedTextField(a,{a=it.filter(Char::isDigit)},label={Text("Tuổi")},singleLine=true)
                OutlinedTextField(h,{h=it.filter{it.isDigit()||it=='.'}},label={Text("Chiều cao (cm)")},singleLine=true)
                OutlinedTextField(w,{w=it.filter{it.isDigit()||it=='.'}},label={Text("Cân nặng (kg)")},singleLine=true)
                OutlinedTextField(act,{act=it.filter{it.isDigit()||it=='.'}},label={Text("Hệ số vận động (1.2–1.9)")},singleLine=true)
                OutlinedTextField(kcal,{kcal=it.filter(Char::isDigit)},label={Text("Mục tiêu kcal/ngày (trống = TDEE + 300)")},singleLine=true)
                OutlinedTextField(protein,{protein=it.filter(Char::isDigit)},label={Text("Mục tiêu protein g/ngày (trống = 2g/kg)")},singleLine=true)
            }
        },
        confirmButton={
            Button(onClick={
                onSave(
                    a.toIntOrNull()?:age,h.toDoubleOrNull()?:height,w.toDoubleOrNull()?:weight,
                    (act.toDoubleOrNull()?:activity).coerceIn(1.2,1.9),
                    kcal.toIntOrNull()?:0,protein.toIntOrNull()?:0
                )
            }){Text("Lưu")}
        },
        dismissButton={TextButton(onClick=onDismiss){Text("Hủy")}}
    )
}

@Composable
fun Eat(m:Modifier,k:Double,pr:Double,kg:Int,pg:Int,cg:Int,fg:Int,add:(Food,Double)->Unit,reset:()->Unit){
    var f by remember{mutableStateOf(FOOD_DB.first())}
    var grams by remember{mutableStateOf("100")}
    var open by remember{mutableStateOf(false)}
    val score=minOf(if(kg>0)k/kg else 0.0,if(pg>0)pr/pg else 0.0,1.0)
    LazyColumn(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{
            Text("🎯 TIẾN ĐỘ HÔM NAY",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text("${(score*100).roundToInt()}% dinh dưỡng")
            LinearProgressIndicator(progress={score.toFloat().coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                Card(Modifier.weight(1f)){Text("Kcal\n${k.roundToInt()}/$kg",Modifier.padding(12.dp))}
                Card(Modifier.weight(1f)){Text("Protein\n${pr.roundToInt()}/${pg}g",Modifier.padding(12.dp))}
            }
            Text("Mục tiêu: $kg kcal • $pg g protein • $cg g carb • $fg g fat")
            Spacer(Modifier.height(4.dp))
            Box{
                OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){Text(f.name)}
                DropdownMenu(expanded=open,onDismissRequest={open=false}){
                    FOOD_DB.forEach{x->DropdownMenuItem(text={Text(x.name)},onClick={f=x;open=false})}
                }
            }
            OutlinedTextField(
                value=grams,onValueChange={grams=it.filter(Char::isDigit)},
                label={Text("Khối lượng (g)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),
                modifier=Modifier.fillMaxWidth()
            )
            Button(onClick={add(f,grams.toDoubleOrNull()?:100.0)},modifier=Modifier.fillMaxWidth()){Text("Thêm vào hôm nay")}
            OutlinedButton(onClick=reset,modifier=Modifier.fillMaxWidth()){Text("Xóa dữ liệu hôm nay")}
            HorizontalDivider()
            Text("⚙️ Mục tiêu dinh dưỡng",fontWeight=FontWeight.Bold)
            Text("TDEE hiện tại: $kg kcal",style=MaterialTheme.typography.bodyLarge)
            Text("Để chỉnh TDEE/tuổi/cân nặng và mục tiêu kcal, vào tab Tập → Cài đặt cơ thể.")
        }
    }
}

@Composable
fun Train(
    m:Modifier,gym:Boolean,run:Boolean,gymSeconds:Long,runSeconds:Long,
    onGym:()->Unit,onRun:()->Unit,onGymSeconds:(Long)->Unit,onRunSeconds:(Long)->Unit
){
    var gymRunning by remember{mutableStateOf(false)}
    var runRunning by remember{mutableStateOf(false)}
    var showSettings by remember{mutableStateOf(false)}
    var ageText by remember{mutableStateOf("36")}
    var heightText by remember{mutableStateOf("182")}
    var weightText by remember{mutableStateOf("73")}

    LaunchedEffect(gymRunning,runRunning){
        while(gymRunning || runRunning){
            delay(1000)
            if(gymRunning) onGymSeconds(gymSeconds+1)
            if(runRunning) onRunSeconds(runSeconds+1)
        }
    }

    LazyColumn(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Text("🏋️ TẬP",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            OutlinedButton(onClick={showSettings=true},modifier=Modifier.fillMaxWidth()){Text("⚙️ Cài đặt cơ thể & mục tiêu kcal")}
        }
        item{
            Card{
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Text("Gym hôm nay",fontWeight=FontWeight.Bold)
                    Text(if(gym)"Đã hoàn thành" else "Chưa hoàn thành")
                    Text("Thời gian: ${formatTime(gymSeconds)}")
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Button(onClick={gymRunning=!gymRunning}){Text(if(gymRunning)"Dừng" else "Bắt đầu")}
                        OutlinedButton(onClick=onGym){Text(if(gym)"Bỏ hoàn thành" else "Hoàn thành")}
                    }
                }
            }
        }
        item{
            Card{
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Text("Chạy hôm nay",fontWeight=FontWeight.Bold)
                    Text(if(run)"Đã hoàn thành" else "Chưa hoàn thành")
                    Text("Thời gian: ${formatTime(runSeconds)}")
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Button(onClick={runRunning=!runRunning}){Text(if(runRunning)"Dừng" else "Bắt đầu")}
                        OutlinedButton(onClick=onRun){Text(if(run)"Bỏ hoàn thành" else "Hoàn thành")}
                    }
                }
            }
        }
        item{Text("Bản V2: có đồng hồ thời gian tập và lưu kết quả trong ngày.")}
    }

    if(showSettings){
        AlertDialog(
            onDismissRequest={showSettings=false},
            title={Text("Cài đặt cơ thể & TDEE")},
            text={
                Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedTextField(ageText,{ageText=it.filter(Char::isDigit)},label={Text("Tuổi")},singleLine=true)
                    OutlinedTextField(heightText,{heightText=it.filter(Char::isDigit)},label={Text("Chiều cao (cm)")},singleLine=true)
                    OutlinedTextField(weightText,{weightText=it.filter{it.isDigit()||it=='.'}},label={Text("Cân nặng (kg)")},singleLine=true)
                    Text("Sau khi nhập, hãy bấm Lưu. TDEE sẽ được tính tự động.")
                }
            },
            confirmButton={Button(onClick={showSettings=false}){Text("Lưu")}},
            dismissButton={TextButton(onClick={showSettings=false}){Text("Đóng")}}
        )
    }
}

fun formatTime(sec:Long):String{
    val h=sec/3600
    val m=(sec%3600)/60
    val s=sec%60
    return "%02d:%02d:%02d".format(h,m,s)
}

@Composable
fun Marathon(m:Modifier){
    var done by remember{mutableStateOf(setOf<Int>())}
    LazyColumn(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        item{
            Text("🏃 MARATHON",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text("Kế hoạch 4 tuần • có pace và đánh dấu hoàn thành.")
        }
        items(RUN_PLAN.indices.toList()){i->
            val x=RUN_PLAN[i]
            Card{
                Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                    Checkbox(checked=i in done,onCheckedChange={done=if(i in done)done-i else done+i})
                    Column{Text(x.day,fontWeight=FontWeight.Bold);Text("${x.type} • ${x.distance}");Text("Pace: ${x.pace}")}
                }
            }
        }
    }
}

@Composable
fun Train(
    m:Modifier,gym:Boolean,run:Boolean,gymSeconds:Long,runSeconds:Long,
    onGym:()->Unit,onRun:()->Unit,onGymSeconds:(Long)->Unit,onRunSeconds:(Long)->Unit,
    onSettings:()->Unit
){
    var gymRunning by remember{mutableStateOf(false)}
    var runRunning by remember{mutableStateOf(false)}
    LaunchedEffect(gymRunning,runRunning){
        while(gymRunning || runRunning){
            delay(1000)
            if(gymRunning) onGymSeconds(gymSeconds+1)
            if(runRunning) onRunSeconds(runSeconds+1)
        }
    }
    LazyColumn(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Text("🏋️ TẬP",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            OutlinedButton(onClick=onSettings,modifier=Modifier.fillMaxWidth()){Text("⚙️ Cài đặt TDEE & mục tiêu kcal")}
        }
        item{
            Card{Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("Gym hôm nay",fontWeight=FontWeight.Bold)
                Text(if(gym)"Đã hoàn thành" else "Chưa hoàn thành")
                Text("Thời gian: ${formatTime(gymSeconds)}")
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Button(onClick={gymRunning=!gymRunning}){Text(if(gymRunning)"Dừng" else "Bắt đầu")}
                    OutlinedButton(onClick=onGym){Text(if(gym)"Bỏ hoàn thành" else "Hoàn thành")}
                }
            }}
        }
        item{
            Card{Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("Chạy hôm nay",fontWeight=FontWeight.Bold)
                Text(if(run)"Đã hoàn thành" else "Chưa hoàn thành")
                Text("Thời gian: ${formatTime(runSeconds)}")
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Button(onClick={runRunning=!runRunning}){Text(if(runRunning)"Dừng" else "Bắt đầu")}
                    OutlinedButton(onClick=onRun){Text(if(run)"Bỏ hoàn thành" else "Hoàn thành")}
                }
            }}
        }
        item{Text("Thời gian tập được lưu lại trên máy.")}
    }
}
