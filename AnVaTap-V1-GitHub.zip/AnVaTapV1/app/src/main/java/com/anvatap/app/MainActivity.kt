package com.anvatap.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

data class Food(val name:String,val kcal:Double,val protein:Double,val carb:Double,val fat:Double)
data class RunPlan(val day:String,val type:String,val distance:String,val pace:String)

val FOOD_DB=listOf(
 Food("Cơm trắng",130.0,2.7,28.0,0.3), Food("Ức gà",165.0,31.0,0.0,3.6),
 Food("Thịt bò",250.0,26.0,0.0,15.0), Food("Cá",150.0,22.0,0.0,6.0),
 Food("Trứng gà",143.0,12.6,0.7,9.5), Food("Sữa tươi",60.0,3.2,4.8,3.2),
 Food("Whey",400.0,75.0,10.0,6.0), Food("Rau xanh",25.0,2.0,4.0,0.3),
 Food("Chuối",89.0,1.1,23.0,0.3)
)
val RUN_PLAN=listOf(
 RunPlan("Tuần 1 • T2","Easy","6 km","6:00–6:30/km"),
 RunPlan("Tuần 1 • T4","Tempo","6 km","5:10–5:30/km"),
 RunPlan("Tuần 1 • T7","Long run","12 km","6:00–6:30/km"),
 RunPlan("Tuần 2 • T2","Easy","7 km","6:00–6:30/km"),
 RunPlan("Tuần 2 • T4","Interval","6×800 m","4:40–5:00/km"),
 RunPlan("Tuần 2 • T7","Long run","15 km","5:50–6:20/km"),
 RunPlan("Tuần 3 • T2","Easy","7 km","5:50–6:20/km"),
 RunPlan("Tuần 3 • T5","Tempo","8 km","5:00–5:20/km"),
 RunPlan("Tuần 3 • CN","Long run","18 km","5:50–6:20/km"),
 RunPlan("Tuần 4 • T2","Recovery","5 km","6:15–6:45/km"),
 RunPlan("Tuần 4 • T4","Interval","5×1 km","4:35–4:55/km"),
 RunPlan("Tuần 4 • T7","Long run","12 km","6:00–6:30/km")
)

class MainActivity:ComponentActivity(){
 private val ask=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) ask.launch(Manifest.permission.POST_NOTIFICATIONS)
  setContent{AnVaTap(this)}
 }
}

@Composable fun AnVaTap(c:Context){
 val p=c.getSharedPreferences("anvatap",0)
 var page by remember{mutableIntStateOf(0)}
 var kcal by remember{mutableDoubleStateOf(p.getFloat("kcal",0f).toDouble())}
 var protein by remember{mutableDoubleStateOf(p.getFloat("protein",0f).toDouble())}
 var gym by remember{mutableStateOf(p.getBoolean("gym",false))}
 var run by remember{mutableStateOf(p.getBoolean("run",false))}
 val age=p.getInt("age",36); val h=p.getFloat("height",182f).toDouble(); val w=p.getFloat("weight",73f).toDouble()
 val bmr=10*w+6.25*h-5*age+5; val goal=(bmr*1.55+300).roundToInt()
 val pg=(w*2).roundToInt(); val fg=(w*.9).roundToInt(); val cg=((goal-pg*4-fg*9)/4).roundToInt()
 fun save(){p.edit().putFloat("kcal",kcal.toFloat()).putFloat("protein",protein.toFloat()).putBoolean("gym",gym).putBoolean("run",run).apply()}
 MaterialTheme(colorScheme=darkColorScheme()){
  Scaffold(topBar={TopAppBar(title={Text("Ăn và Tập",fontWeight=FontWeight.Bold)})},
   bottomBar={NavigationBar{listOf("Ăn","Tập","Marathon").forEachIndexed{i,s->NavigationBarItem(page==i,{page=i},{Icon(if(i==0)Icons.Default.Restaurant else if(i==1)Icons.Default.FitnessCenter else Icons.Default.DirectionsRun,s)},label={Text(s)})}}},
  ){pad->when(page){
   0->Eat(Modifier.padding(pad),kcal,protein,goal,pg,cg,fg,save,{f,g->kcal+=f.kcal*g/100;protein+=f.protein*g/100;save()},{kcal=0.0;protein=0.0;save()})
   1->Train(Modifier.padding(pad),gym,run,{gym=!gym;save()},{run=!run;save()})
   2->Marathon(Modifier.padding(pad))
  }}
 }
}

@Composable fun Eat(m:Modifier,k:Double,pr:Double,kg:Int,pg:Int,cg:Int,fg:Int,save:()->Unit,add:(Food,Double)->Unit,reset:()->Unit){
 var f by remember{mutableStateOf(FOOD_DB.first())}; var grams by remember{mutableStateOf("100")}; var open by remember{mutableStateOf(false)}
 val score=minOf(k/kg,pr/pg,1.0)
 Column(m.fillMaxSize().padding(16.dp)){Text("🎯 TIẾN ĐỘ HÔM NAY",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
  Text("${(score*100).roundToInt()}% dinh dưỡng");LinearProgressIndicator({score.toFloat().coerceIn(0f,1f)},Modifier.fillMaxWidth())
  Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Card(Modifier.weight(1f)){Text("Kcal\n${k.roundToInt()}/$kg",Modifier.padding(12.dp))};Card(Modifier.weight(1f)){Text("Protein\n${pr.roundToInt()}/${pg}g",Modifier.padding(12.dp))}}
  Text("Mục tiêu: $kg kcal • $pg g protein • $cg g carb • $fg g fat",Modifier.padding(vertical=12.dp))
  Box{OutlinedButton({open=true},Modifier.fillMaxWidth()){Text(f.name)};DropdownMenu(open,{open=false}){FOOD_DB.forEach{x->DropdownMenuItem({Text(x.name)},{f=x;open=false})}}}
  OutlinedTextField(grams,{grams=it.filter(Char::isDigit)},label={Text("Khối lượng (g)")},modifier=Modifier.fillMaxWidth())
  Button({add(f,grams.toDoubleOrNull()?:100.0)},Modifier.fillMaxWidth()){Text("Thêm vào hôm nay")}
  OutlinedButton(reset,Modifier.fillMaxWidth()){Text("Xóa dữ liệu hôm nay")}
 }
}

@Composable fun Train(m:Modifier,gym:Boolean,run:Boolean,toggleGym:()->Unit,toggleRun:()->Unit){
 Column(m.fillMaxSize().padding(16.dp)){Text("🏋️ TẬP",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
  Card{Column(Modifier.padding(16.dp)){Text("Gym hôm nay",fontWeight=FontWeight.Bold);Text(if(gym)"Đã hoàn thành" else "Chưa hoàn thành");Button(toggleGym){Text(if(gym)"Bỏ hoàn thành" else "Hoàn thành gym")}}}
  Spacer(Modifier.height(12.dp));Card{Column(Modifier.padding(16.dp)){Text("Chạy hôm nay",fontWeight=FontWeight.Bold);Text(if(run)"Đã hoàn thành" else "Chưa hoàn thành");Button(toggleRun){Text(if(run)"Bỏ hoàn thành" else "Hoàn thành chạy")}}}
  Spacer(Modifier.height(12.dp));Text("Bản V1: khung theo dõi. Các bản tiếp theo thêm bài tập, sets/reps/kg, volume và rest timer.")
 }
}

@Composable fun Marathon(m:Modifier){
 var done by remember{mutableStateOf(setOf<Int>())}
 LazyColumn(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Text("🏃 MARATHON",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Kế hoạch 4 tuần • có thể điều chỉnh mục tiêu.");Spacer(Modifier.height(8.dp))}
  items(RUN_PLAN.indices.toList()){i->val x=RUN_PLAN[i];Card{Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(i in done,{done=if(i in done)done-i else done+i});Column{Text(x.day,fontWeight=FontWeight.Bold);Text("${x.type} • ${x.distance}");Text("Pace: ${x.pace}")}}}}
 }
}
