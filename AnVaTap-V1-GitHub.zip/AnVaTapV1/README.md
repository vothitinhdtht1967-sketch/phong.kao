# Ăn và Tập — V1

Bản MVP Android gồm 3 khu vực: Ăn, Tập, Marathon.

- TDEE/macro tự động theo hồ sơ
- Nhập thực phẩm theo gram
- Theo dõi kcal/protein trong ngày
- Đánh dấu hoàn thành gym/chạy
- Kế hoạch marathon 4 tuần
- GitHub Actions tự build APK debug

## Build bằng điện thoại
1. Upload toàn bộ thư mục/file của project lên repository GitHub.
2. Mở tab Actions.
3. Chọn workflow Build Android APK.
4. Nhấn Run workflow.
5. Khi chạy xong, tải artifact AnVaTap-debug và lấy file app-debug.apk.

Đây là V1 để dựng và build APK. Các bản sau có thể bổ sung Room database, lịch sử ngày/tuần/tháng, biểu đồ cân nặng, sets/reps/kg, rest timer, nhắc ăn/tập/chạy và backup/restore.
