# Ăn và Tập V2

Android app Jetpack Compose.

## V2
- Tính BMR/TDEE từ tuổi, chiều cao, cân nặng, giới tính và mức vận động.
- Chọn mục tiêu tăng/giữ/giảm cân.
- Cho phép chỉnh Kcal và protein mục tiêu.
- Lịch giờ tập Gym/Chạy, thời lượng dự kiến và đồng hồ buổi tập.
- Kế hoạch Marathon 4 tuần có giờ, thời lượng và lưu trạng thái hoàn thành.
