package com.anvatap.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

data class Food(val name:String,val kcal:Double,val protein:Double,val carb:Double,val fat:Double)
data class RunPlan(val day:String,val type:String,val distance:String,val pace:String,val time:String,val duration:Int)

data class Profile(val age:Int,val height:Double,val weight:Double,val male:Boolean,val activity:Double,val goal:String)

val FOOD_DB=listOf(
 Food("Cơm trắng",130.0,2.7,28.0,0.3), Food("Ức gà",165.0,31.0,0.0,3.6),
 Food("Thịt bò",250.0,26.0,0.0,15.0), Food("Cá",150.0,22.0,0.0,6.0),
 Food("Trứng gà",143.0,12.6,0.7,9.5), Food("Sữa tươi",60.0,3.2,4.8,3.2),
 Food("Whey",400.0,75.0,10.0,6.0), Food("Rau xanh",25.0,2.0,4.0,0.3),
 Food("Chuối",89.0,1.1,23.0,0.3)
)

val RUN_PLAN=listOf(
 RunPlan("Tuần 1 • T2","Easy","6 km","6:00–6:30/km","06:00",45),
 RunPlan("Tuần 1 • T4","Tempo","6 km","5:10–5:30/km","18:00",40),
 RunPlan("Tuần 1 • T7","Long run","12 km","6:00–6:30/km","06:00",75),
 RunPlan("Tuần 2 • T2","Easy","7 km","6:00–6:30/km","06:00",50),
 RunPlan("Tuần 2 • T4","Interval","6×800 m","4:40–5:00/km","18:00",45),
 RunPlan("Tuần 2 • T7","Long run","15 km","5:50–6:20/km","06:00",90),
 RunPlan("Tuần 3 • T2","Easy","7 km","5:50–6:20/km","06:00",50),
 RunPlan("Tuần 3 • T5","Tempo","8 km","5:00–5:20/km","18:00",50),
 RunPlan("Tuần 3 • CN","Long run","18 km","5:50–6:20/km","06:00",110),
 RunPlan("Tuần 4 • T2","Recovery","5 km","6:15–6:45/km","06:00",35),
 RunPlan("Tuần 4 • T4","Interval","5×1 km","4:35–4:55/km","18:00",50),
 RunPlan("Tuần 4 • T7","Long run","12 km","6:00–6:30/km","06:00",75)
)

class MainActivity:ComponentActivity(){
 private val ask=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) ask.launch(Manifest.permission.POST_NOTIFICATIONS)
  setContent{AnVaTap(this)}
 }
}

fun calcBmr(profile:Profile):Double = if(profile.male) 10*profile.weight+6.25*profile.height-5*profile.age+5 else 10*profile.weight+6.25*profile.height-5*profile.age-161
fun calcTdee(profile:Profile):Double = calcBmr(profile)*profile.activity
fun autoCalories(profile:Profile):Int {
 val t=calcTdee(profile)
 return when(profile.goal){"Tăng cân"->(t+300).roundToInt();"Giảm cân"->(t-400).roundToInt();else->t.roundToInt()}
}

@Composable fun AnVaTap(c:Context){
 val p=c.getSharedPreferences("anvatap",0)
 var page by remember{mutableIntStateOf(0)}
 val defaultProfile=Profile(p.getInt("age",36),p.getFloat("height",182f).toDouble(),p.getFloat("weight",73f).toDouble(),p.getBoolean("male",true),p.getFloat("activity",1.55f).toDouble(),p.getString("goalMode","Tăng cân")?:"Tăng cân")
 var profile by remember{mutableStateOf(defaultProfile)}
 var targetKcal by remember{mutableIntStateOf(p.getInt("targetKcal",autoCalories(defaultProfile)))}
 var targetProtein by remember{mutableIntStateOf(p.getInt("targetProtein",(defaultProfile.weight*2).roundToInt()))}
 var kcal by remember{mutableDoubleStateOf(p.getFloat("kcal",0f).toDouble())}
 var protein by remember{mutableDoubleStateOf(p.getFloat("protein",0f).toDouble())}
 var gym by remember{mutableStateOf(p.getBoolean("gym",false))}
 var run by remember{mutableStateOf(p.getBoolean("run",false))}
 var showSettings by remember{mutableStateOf(false)}
 fun save(){p.edit().putFloat("kcal",kcal.toFloat()).putFloat("protein",protein.toFloat()).putBoolean("gym",gym).putBoolean("run",run).putInt("targetKcal",targetKcal).putInt("targetProtein",targetProtein).putInt("age",profile.age).putFloat("height",profile.height.toFloat()).putFloat("weight",profile.weight.toFloat()).putBoolean("male",profile.male).putFloat("activity",profile.activity.toFloat()).putString("goalMode",profile.goal).apply()}
 MaterialTheme(colorScheme=darkColorScheme()){
  Scaffold(topBar={TopAppBar(title={Text("Ăn và Tập",fontWeight=FontWeight.Bold)},actions={IconButton({showSettings=true}){Icon(Icons.Default.Settings,"Cài đặt")}})},
   bottomBar={NavigationBar{listOf("Ăn","Tập","Marathon").forEachIndexed{i,s->NavigationBarItem(page==i,{page=i},{Icon(if(i==0)Icons.Default.Restaurant else if(i==1)Icons.Default.FitnessCenter else Icons.Default.DirectionsRun,s)},label={Text(s)})}}},
  ){pad->when(page){
   0->Eat(Modifier.padding(pad),kcal,protein,targetKcal,targetProtein,profile,save,{f,g->kcal+=f.kcal*g/100;protein+=f.protein*g/100;save()},{kcal=0.0;protein=0.0;save()})
   1->Train(Modifier.padding(pad),gym,run,{gym=!gym;save()},{run=!run;save()},p)
   2->Marathon(Modifier.padding(pad),p)
  }}
  if(showSettings) ProfileDialog(profile,targetKcal,targetProtein,{pr,k,pro -> profile=pr; targetKcal=k; targetProtein=pro; save(); showSettings=false},{showSettings=false})
 }
}

@Composable fun ProfileDialog(profile:Profile,initialKcal:Int,initialProtein:Int,onSave:(Profile,Int,Int)->Unit,onDismiss:()->Unit){
 var age by remember{mutableStateOf(profile.age.toString())}; var height by remember{mutableStateOf(profile.height.roundToInt().toString())}; var weight by remember{mutableStateOf(profile.weight.toString())}
 var male by remember{mutableStateOf(profile.male)}; var activity by remember{mutableStateOf(profile.activity)}; var goal by remember{mutableStateOf(profile.goal)}
 var kcal by remember{mutableStateOf(initialKcal.toString())}; var protein by remember{mutableStateOf(initialProtein.toString())}; var activityOpen by remember{mutableStateOf(false)}; var goalOpen by remember{mutableStateOf(false)}
 val temp=Profile(age.toIntOrNull()?:36,height.toDoubleOrNull()?:182.0,weight.toDoubleOrNull()?:73.0,male,activity,goal); val tdee=calcTdee(temp).roundToInt(); val auto=autoCalories(temp)
 AlertDialog(onDismissRequest=onDismiss,title={Text("TDEE & mục tiêu dinh dưỡng")},text={
  Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(age,{age=it.filter(Char::isDigit)},label={Text("Tuổi")},modifier=Modifier.weight(1f));OutlinedTextField(weight,{weight=it.filter{c->c.isDigit()||c=='.'}},label={Text("Cân nặng kg")},modifier=Modifier.weight(1f))}
   OutlinedTextField(height,{height=it.filter{c->c.isDigit()||c=='.'}},label={Text("Chiều cao cm")},modifier=Modifier.fillMaxWidth())
   Row(verticalAlignment=Alignment.CenterVertically){RadioButton(male,{male=true});Text("Nam");Spacer(Modifier.width(16.dp));RadioButton(!male,{male=false});Text("Nữ")}
   Box{OutlinedButton({activityOpen=true},Modifier.fillMaxWidth()){Text("Mức vận động: ${activityName(activity)}")};DropdownMenu(activityOpen,{activityOpen=false}){listOf(1.2 to "Ít vận động",1.375 to "Nhẹ",1.55 to "Vừa",1.725 to "Cao",1.9 to "Rất cao").forEach{(v,n)->DropdownMenuItem({Text(n)},{activity=v;activityOpen=false})}}}
   Box{OutlinedButton({goalOpen=true},Modifier.fillMaxWidth()){Text("Mục tiêu: $goal")};DropdownMenu(goalOpen,{goalOpen=false}){listOf("Tăng cân","Giữ cân","Giảm cân").forEach{x->DropdownMenuItem({Text(x)},{goal=x;goalOpen=false})}}}
   Text("BMR: ${calcBmr(temp).roundToInt()} kcal • TDEE: $tdee kcal",fontWeight=FontWeight.Bold)
   Text("Kcal đề xuất: $auto kcal")
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(kcal,{kcal=it.filter(Char::isDigit)},label={Text("Kcal mục tiêu")},modifier=Modifier.weight(1f));OutlinedTextField(protein,{protein=it.filter(Char::isDigit)},label={Text("Protein g")},modifier=Modifier.weight(1f))}
   Text("Có thể sửa Kcal/Protein theo ý muốn rồi bấm Lưu.",style=MaterialTheme.typography.bodySmall)
  }
 },confirmButton={Button({onSave(temp,kcal.toIntOrNull()?:auto,protein.toIntOrNull()?:temp.weight.roundToInt()*2)}){Text("Lưu")}},dismissButton={TextButton(onDismiss){Text("Hủy")}})
}
fun activityName(v:Double)=when(v){1.2->"Ít vận động";1.375->"Nhẹ";1.55->"Vừa";1.725->"Cao";else->"Rất cao"}

@Composable fun Eat(m:Modifier,k:Double,pr:Double,kg:Int,pg:Int,profile:Profile,save:()->Unit,add:(Food,Double)->Unit,reset:()->Unit){
 var f by remember{mutableStateOf(FOOD_DB.first())}; var grams by remember{mutableStateOf("100")}; var open by remember{mutableStateOf(false)}
 val cg=((kg-pg*4-profile.weight*.9*9)/4).roundToInt().coerceAtLeast(0); val fg=(profile.weight*.9).roundToInt(); val score=minOf(k/kg,pr/pg,1.0)
 Column(m.fillMaxSize().padding(16.dp)){Text("🎯 TIẾN ĐỘ HÔM NAY",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("${(score*100).roundToInt()}% dinh dưỡng");LinearProgressIndicator({score.toFloat().coerceIn(0f,1f)},Modifier.fillMaxWidth())
  Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Card(Modifier.weight(1f)){Text("Kcal\n${k.roundToInt()}/$kg",Modifier.padding(12.dp))};Card(Modifier.weight(1f)){Text("Protein\n${pr.roundToInt()}/${pg}g",Modifier.padding(12.dp))}}
  Text("TDEE: ${calcTdee(profile).roundToInt()} kcal • Mục tiêu: $kg kcal • $pg g protein • $cg g carb • $fg g fat",Modifier.padding(vertical=12.dp))
  Box{OutlinedButton({open=true},Modifier.fillMaxWidth()){Text(f.name)};DropdownMenu(open,{open=false}){FOOD_DB.forEach{x->DropdownMenuItem({Text(x.name)},{f=x;open=false})}}}
  OutlinedTextField(grams,{grams=it.filter(Char::isDigit)},label={Text("Khối lượng (g)")},modifier=Modifier.fillMaxWidth())
  Button({add(f,grams.toDoubleOrNull()?:100.0)},Modifier.fillMaxWidth()){Text("Thêm vào hôm nay")};OutlinedButton(reset,Modifier.fillMaxWidth()){Text("Xóa dữ liệu hôm nay")}
  Text("⚙️ Bấm biểu tượng cài đặt góc trên để đổi TDEE, kcal và protein mục tiêu.",style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(top=8.dp))
 }
}

@Composable fun Train(m:Modifier,gym:Boolean,run:Boolean,toggleGym:()->Unit,toggleRun:()->Unit,p:android.content.SharedPreferences){
 var gymTime by remember{mutableStateOf(p.getString("gymTime","18:00")?:"18:00")}; var gymDur by remember{mutableStateOf(p.getInt("gymDur",60).toString())}; var runTime by remember{mutableStateOf(p.getString("runTime","06:00")?:"06:00")}; var runDur by remember{mutableStateOf(p.getInt("runDur",45).toString())}
 var running by remember{mutableStateOf(false)}; var elapsed by remember{mutableLongStateOf(0L)}; var startedAt by remember{mutableLongStateOf(0L)}
 LaunchedEffect(running){while(running){elapsed=System.currentTimeMillis()-startedAt;delay(1000)}}
 Column(m.fillMaxSize().padding(16.dp)){Text("🏋️ TẬP",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Lịch giờ tập + bấm bắt đầu để đo thời gian thực tế.",style=MaterialTheme.typography.bodySmall);Spacer(Modifier.height(8.dp))
  Card{Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Gym",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(gymTime,{gymTime=it; p.edit().putString("gymTime",it).apply()},label={Text("Giờ")},modifier=Modifier.weight(1f));OutlinedTextField(gymDur,{gymDur=it.filter(Char::isDigit);p.edit().putInt("gymDur",gymDur.toIntOrNull()?:60).apply()},label={Text("Phút")},modifier=Modifier.weight(1f))};Text(if(gym)"✓ Đã hoàn thành" else "Chưa hoàn thành");Button(toggleGym){Text(if(gym)"Bỏ hoàn thành" else "Hoàn thành gym")}}}
  Spacer(Modifier.height(10.dp));Card{Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Chạy",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(runTime,{runTime=it;p.edit().putString("runTime",it).apply()},label={Text("Giờ")},modifier=Modifier.weight(1f));OutlinedTextField(runDur,{runDur=it.filter(Char::isDigit);p.edit().putInt("runDur",runDur.toIntOrNull()?:45).apply()},label={Text("Phút")},modifier=Modifier.weight(1f))};Text(if(run)"✓ Đã hoàn thành" else "Chưa hoàn thành");Button(toggleRun){Text(if(run)"Bỏ hoàn thành" else "Hoàn thành chạy")}}}
  Spacer(Modifier.height(12.dp));Card{Column(Modifier.padding(16.dp)){Text("⏱ Đồng hồ buổi tập",fontWeight=FontWeight.Bold);Text(formatMs(elapsed),style=MaterialTheme.typography.headlineMedium);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({if(!running){startedAt=System.currentTimeMillis()-elapsed;running=true}else running=false}){Text(if(running)"Tạm dừng" else "Bắt đầu")};OutlinedButton({running=false;elapsed=0}){Text("Đặt lại")}}}}
 }
}
fun formatMs(ms:Long):String{val s=ms/1000;return "%02d:%02d:%02d".format(s/3600,(s%3600)/60,s%60)}

@Composable fun Marathon(m:Modifier,p:android.content.SharedPreferences){
 var done by remember{mutableStateOf((0 until RUN_PLAN.size).filter{p.getBoolean("runplan_$it",false)}.toSet())}
 val completed=done.size
 LazyColumn(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Text("🏃 MARATHON",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Kế hoạch 4 tuần • $completed/${RUN_PLAN.size} buổi hoàn thành");Spacer(Modifier.height(8.dp))}
  items(RUN_PLAN.indices.toList()){i->val x=RUN_PLAN[i];Card{Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(i in done,{done=if(i in done){p.edit().putBoolean("runplan_$i",false).apply();done-i}else{p.edit().putBoolean("runplan_$i",true).apply();done+i}});Column{Text(x.day,fontWeight=FontWeight.Bold);Text("${x.type} • ${x.distance}");Text("Pace: ${x.pace} • ${x.time} • ${x.duration} phút")}}}}
 }
}
